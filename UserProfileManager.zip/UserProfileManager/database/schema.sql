CREATE DATABASE userdb;

USE userdb;

CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100),
  email VARCHAR(100),
  phone VARCHAR(15),
  dob DATE,
  role VARCHAR(50)
);
