package com.demo.UserProfileManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserProfileManagerApplication {
    public static void main(String[] args){
        SpringApplication.run(UserProfileManagerApplication.class,args);
    }
}
