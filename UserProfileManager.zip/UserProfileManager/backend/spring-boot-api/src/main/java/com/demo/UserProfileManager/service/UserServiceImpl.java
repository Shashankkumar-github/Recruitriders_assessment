package com.demo.UserProfileManager.service;

import com.demo.UserProfileManager.model.User;
import com.demo.UserProfileManager.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository userRepository;

    @Override
    public List<User> getAllUsers(){
        return userRepository.findAll();
    }
    @Override
    public User createUser( User user){
        return userRepository.save(user);
    }
    @Override
    public User updateUser(Long id, User updatedUser){
        return userRepository.findById(id).map(user -> {
            user.setName(updatedUser.getName());
            user.setEmail(updatedUser.getEmail());
            user.setPhone(updatedUser.getPhone());
            user.setDob(updatedUser.getDob());
            user.setRole(updatedUser.getRole());
            return userRepository.save(user);
        }).orElseThrow(() -> new RuntimeException("User not found"));

    }

    @Override
    public void deleteUser( Long id){
        userRepository.deleteById(id);
    }
}
