// JS for form validation and API calls

const URL = 'http://localhost:8080/api/users';
const form =document.getElementById('userForm');
const tbody = document.getElementById('tableBody');
 const editID = null;
form.addEventListener('submit',async(e) => {
e.preventDefault();
const user = {
name: form.name.value,
email: form.email.value,
phone : form.phone.value,
dob: form.dob.value,
role: form.role.value,
};

if(!validated(user)) return;
const method = editID ? 'PUT' : 'POST';
const url = editID ? `${URL}/${editID}`:URL;
const res = await fetch(url,{
method, headers:{'Content-Type':'application/json'},
body:JSON.stringify(user)
});
if(res.ok){
form.reset();
editID =null;
loadUsers();
}

});

function loadUsers(){
const res = await fetch(URL);
const users = await res.json();
tbody.innerHTML ='';
users.forEach(user => {
const row = document.createElement('tr');
row.innerHTML = `
<td> ${user.name} </td>
<td> ${user.email} </td>
<td> ${user.phone} </td>
<td> ${user.dob} </td>
<td> ${user.role} </td>
<td> <button onclick='editUser(${JSON.stringify(user)})'> EDIT </button>
<button onclick='deleteUser(${user.id})'> DELETE </button>
</td>
`;
tbody.appendChild(row);
});

}

function editUser(user){
form.name.value = user.name;
form.email.value = user.email;
form.phone.value = user.phone;
form.dob.value = user.dob;
form.role.value =user.role;
editID =user.id;

}
async function deleteUser(id){
await fetch(`${URL}/${id}`,{method :'DELETE'});
loadUsers();
}


function validated(user){
if(!user.name || !user.email ||!user.phone || !user.dob || !user.role){
alert('All Fields are required');
return false;
}
const regex = /^[a-zA-Z0-9. _%+-]+@[a-zA-Z0-9;
if(!regex.test(user.email)){
alert('Invalid email');
return false;
}
if(!/^\d{10}.test(user.phone)){
alert('must be of 10 digits only');
return false;

}
return true;
}

window.onload = loadUsers;